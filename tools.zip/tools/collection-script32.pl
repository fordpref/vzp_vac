#!/usr/bin/perl -w
#small simple script to gather  infomration from tester, create
#basic folders to hold assessment data, and perform collection on the systems that need to be tested.

#The structure here will be the modules we need, then the sub routines, then the main body of the program
#that calls the various sub routines/functions to perform the tasks.

#Modules
use strict;
use File::Spec;



#sub routines
sub printarray()
{
    #just a subroutine to look at collected arrays and print them to determine how best to deal with certain input, dies at the end
    my $x = 0;
    my $output;
    my @array=@{$_[0]};
    
    print "\n\n";
    foreach $output (@array)
    {
        print "$x   $output\n";
        $x += 1;
    }
    die "\n\nDone with arrayprint, how does the output look?\n";
}

sub checktoolpath()
{
    my $path;
    print "\n\nType the path to the tools directory or disc:  ";
    chomp($path = <STDIN>);
    $path =~ s/\\/\\\\/g;
    if ($path !~ /\\\\$/)
    {
        $path .= "\\\\";
    }
    if ( !-e $path."psloglist.exe")
    {
        print "** Invalid path, tools not found\n";
        print "** Try again....\n\n";
        $path = "";
        $path = &checktoolpath($path);
    }
    return ($path);
}

sub checklogdate()
{
    my @td = localtime(time);
    my $tz = '';
    my $year;
    my $month;
    my $day;
    my $hour;
    my $minute;
    my $date;
    my %ldays = ("1"=>[31],"3"=>[31],"5"=>[31],"7"=>[31],"8"=>[31],"10"=>[31],"12"=>[31]);
    my %sdays = ("4"=>[30],"6"=>[30],"9"=>[30],"11"=>[30]);
    my $logdays;

    
    #Convert year month and hour to correct formats
    $year = 1900+$td[5];
    $month = $td[4] + 1;
    $day = $td[3];
    
    $logdays = $day - 7;
    
    if ($logdays <= 0)
    {
        $month -= 1;
        if (exists $ldays{$month})
        {
            $day = 31 + $logdays;
        }
        elsif (exists $sdays{$month})
        {
            $day = 30 + $logdays;
        }
        elsif ($month == 2)
        {
            $day = 28 + $logdays;
        }
    }
    else
    {
        $day = $logdays;
    }
    $date = $month."/".$day."/".$year;
    return($date);
}

sub datetime()
{
    my @td = localtime(time);
    my $tz = '';
    my $year;
    my $month;
    my $day;
    my $hour;
    my $minute;
    my $GMT = "GMT";
    my $format;
    
    #get timezone info so we can convert to GMT
    print "\n\n\nTimezone is the number of hours from GMT you are.\n";
    print "example:  EDT is -4 hours from GMT, or GMT-4\n";
    print "In the input below you would type -4.  PDT would be -7.  EST is -5\n";
    print "\nTimeZone: ";
    chomp($tz = <STDIN>);
    
    #Convert year month and hour to correct formats
    $year = 1900+$td[5];
    $month = $td[4] + 1;
    $day = $td[3];
    $hour = $td[2]-$tz;
    $minute = $td[1];
    
    #Add in zeroes where needed
    if ($month < 10)
    {
        $month = "0".$month;
    }
    if ($hour < 10)
    {
        $hour = "0".$hour;
    }
    elsif ($hour >= 24)
    {
        $hour = $hour - 24;
        $hour = "0".$hour;
        $day += 1;
    }
    if ($day < 10)
    {
        $day = "0".$day;
    }
    if ($minute < 10)
    {
        $minute = "0".$minute."GMT";
    }
    else
    {
        $minute = $minute."GMT";
    }
    
    
    #create the whole date time format
    $format = "$year.$month.$day-$hour$minute";
    return ($format);
} 

sub whatos()
{
    my @sysinfo;
    my $os;
    my $line;
    
    @sysinfo = `systeminfo`;
    foreach $line (@sysinfo)
    {
        if ($line =~ /OS\ Name/)
        {
            if ($line=~ m/XP/g or $line=~ m/2003/g)
            {
                $os="xp-2003";
            }
            else
            {
                $os = "2008-win7";
            }
        }
    }
    return($os,@sysinfo);
}

sub assessmentname()
{
    my $name;
    my @ip;
    my $rec;
    my $x = 0;
    my $os = $_[2];
    my $temp;
    

    #system("cls");
    chomp($name = `echo %COMPUTERNAME%`);
        
    if ($os eq "2008-win7")
    {
        chomp(@ip = `ipconfig |findstr IPv4`);

        if (scalar(@ip) == 1)
        {
            $ip[0] =~ s/^.*:\ //g;
            $ip[0] =~ s/\s//g;
            $rec = $ip[0];
        }
        else
        {
            print "\nWhich IP is the primary?\n";
            foreach $rec (@ip)
            {
                $ip[$x] =~ s/^.*:\ //g;
                $ip[$x] =~ s/\s//g;
                print "$x   $ip[$x]\n";
                $x+=1;
            }
            print ":  ";
            $x = 0;
            chomp($x = <STDIN>);
            $rec=$ip[$x];
        }
    }
    else
    {
        chomp(@ip = `ipconfig |findstr /C:"IP Address"`);
        if (scalar(@ip) == 1)
        {
            $ip[0] =~ s/^.*:\ //g;
            $ip[0] =~ s/\s//g;
            $rec = $ip[0];
        }
        else
        {        
            print "\nWhich IP is the primary?\n";
            foreach $rec (@ip)
            {
                $ip[$x] =~ s/^.*:\ //g;
                $ip[$x] =~ s/\s//g;
                print "$x   $ip[$x]\n";
                $x+=1;
            }
            print ":  ";
            $x = 0;
            chomp($x = <STDIN>);
            $rec = $ip[$x];
        }
    }
    return ($name,$rec);
}

sub makedir()
{
    my $name = $_[0];
    my $ip = $_[1];
    my $dir = $_[2];
    
    if (-e $dir)
    {
        system("mkdir $dir$name-$ip");
    }
    else
    {
        system("mkdir $dir");
        system("mkdir $dir$name-$ip");
    }
}

sub registrysetup()
{
    my $path = $_[0];
    system("regedit /s $path"."sysinternals-registry-eulas.reg");    
}

sub collection()
{
    my $dir = $_[0];
    my $name = $_[1];
    my $path = $_[2];
    my $date = $_[3];
    my $os = $_[4];
    my $logpath;
    my @logs;
    my $file;
    my $xcopy;
    my @sysinfo = @{$_[5]};
    my $sysinfofile = $dir.$name."-systeminfo.txt";
    my $line;
    

    
    #Get system date and time
    if ($os eq "2008-win7")
    {
        system("w32tm.exe /query /status >> $dir$name-datetime.txt");
    }
    else
    {
        system("net time /querysntp >> $dir$name-datetime.txt");
    }
    
    #Now collect McAfee and Symantec Registry Entries
    #We are actually just going to get the whole HKEY_Local_Machine/Software hive
    system("regedit.exe /S /E $dir$name-software-registry.reg HKEY_LOCAL_MACHINE\\SOFTWARE");
    
    #output systeminfo collected earlier to file
    open(SYSINFO,">$sysinfofile");
    foreach $line (@sysinfo)
    {
        print SYSINFO $line;
    }
    close(SYSINFO);
    
    #more system utilities
    system("set >> $dir$name-environmentvariables.txt");
    system("ipconfig.exe /all >> $dir$name-ipconfig.txt");
    system("ipconfig.exe /displaydns >> $dir$name-dnscache.txt");
    system("c:\\Windows\\System32\\nbtstat.exe -r >> $dir$name-nbtstat-cached-names.txt");
    system("c:\\Windows\\System32\\nbtstat.exe -S >> $dir$name-nbtstat-remote-sessions.txt");
    system("netstat.exe -nr >> $dir$name-routes.txt");
    system("netstat.exe -nao >> $dir$name-networklisteners.txt");
    system("net.exe accounts >> $dir$name-password-policy.txt");
    &localgroups($dir,$name);
    &users($dir,$name);
    &shares($dir,$name);
    system("netsh.exe firewall show config >> $dir$name-firewall-config.txt");
    system("ver >> $dir$name-win-ver.txt");
    
    
    #Sysinternals tools
    system("$path"."psloggedon.exe >> $dir$name-whois-loggedon.txt");
    system("$path"."psservice.exe >> $dir$name-local-services.txt");
    system("$path"."tcpvcon.exe -a -c -n >> $dir$name-tcpview.csv");
    system("$path"."psloglist.exe -a $date -s system >> $dir$name-system-event-log.csv");
    system("$path"."psloglist.exe -a $date -s application >> $dir$name-application-event-log.csv");
    system("$path"."psloglist.exe -a $date -s security >> $dir$name-security-event-log.csv");
    system("$path"."autorunsc.exe -a -c -m >> $dir$name-autoruns.csv");
    system("$path"."handle.exe -a >> $dir$name-open-handles.txt");
    system("$path"."logonsessions.exe >> $dir$name-logonsessions.txt");
    system("$path"."psfile.exe >> $dir$name-files-opened-remotely.txt");
    system("$path"."psinfo.exe -h -s -d -c >> $dir$name-installed-apps-patches.csv");
    
    #Now collect logs from mcafee and symantec
    chomp($logpath = `echo %ALLUSERSPROFILE%`);
    $logpath =~ s/\\/\\\\/;
    if ($os eq "2008-win7")
    {
        system("xcopy $logpath\\*.log $dir$name\\ /S /H");
        system("xcopy $logpath\\*.txt $dir$name\\ /S /H");
        system("xcopy c:\\windows\\*.log $dir$name\\ /S /H");
    }
    else
    {
        @logs = `dir \"%allusersprofile%\" /S /B|findstr /C:\.log`;
        foreach $file (@logs)
        {
            chomp($file);
            $file =~ s/$/"/;
            $file =~ s/^/"/;
            $xcopy = $dir.$name."-logs\\";
            system("xcopy $file $xcopy /S /H");
        }
        @logs = `dir \"%allusersprofile%\" /S /B|findstr /C:\.txt`;
        foreach $file (@logs)
        {
            chomp($file);
            $file =~ s/$/"/;
            $file =~ s/^/"/;
            $xcopy = $dir.$name."-logs\\";
            system("xcopy $file $xcopy /S /H");
        }
        @logs = `dir c:\\windows\\ /S /B|findstr /C:\.txt`;
        foreach $file (@logs)
        {
            chomp($file);
            $file =~ s/$/"/;
            $file =~ s/^/"/;
            $xcopy = $dir.$name."-logs\\";
            system("xcopy $file $xcopy /S /H");
        }
    }
}

sub users()
{
    my $dir = $_[0];
    my $name = $_[1];
    my @raw;
    my @users;
    my $line;
    
    system("net.exe users >> $dir$name-localusers.txt");
    @raw = `net.exe users`;
    foreach $line (@raw)
    {
        chomp($line);
        if ($line eq "")
        {
            next;
        }
        elsif ($line =~ m/\\\\/g)
        {
            next;
        }
        elsif ($line =~ m/----------/g)
        {
            next;
        }
        elsif ($line =~ m/^The\ command\ completed\ successfully\.$/)
        {
            next;
        }
        else
        {
            push(@users, split(/\s+/,$line));
        }
    }
    foreach $line (@users)
    {
        `echo ************************************** >> $dir$name-localusers.txt`;
        `echo ************************************** >> $dir$name-localusers.txt`;
        system("net.exe users $line >> $dir$name-localusers.txt");
    }
}

sub localgroups()
{
    my $dir = $_[0];
    my $name = $_[1];
    my @raw;
    my @users;
    my $line;
    
    system("net.exe localgroup >> $dir$name-localgroups.txt");
    @raw = `net.exe localgroup`;
    foreach $line (@raw)
    {
        chomp($line);
        
        if ($line eq "")
        {
            next;
        }
        elsif ($line =~ m/\\\\/g)
        {
            next;
        }
        elsif ($line =~ m/----------/g)
        {
            next;
        }
        elsif ($line =~ m/^The\ command\ completed\ successfully\.$/)
        {
            next;
        }
        else
        {
            $line =~ s/^\*//;
            push(@users, $line);
        }
    }
    foreach $line (@users)
    {
        `echo ************************************** >> $dir$name-localgroups.txt`;
        `echo ************************************** >> $dir$name-localgroups.txt`;
        system("net.exe localgroup \"$line\" >> $dir$name-localgroups.txt");
    }
}

sub shares()
{
    my $dir = $_[0];
    my $name = $_[1];
    my @raw;
    my @shares;
    my @lines;
    my $line;
    
    system("net.exe share >> $dir$name-localshares.txt");
    @raw = `net.exe share`;
    foreach $line (@raw)
    {
        if ( $line !~ m/\$/g and $line !~ m/\\/g)
        {
            next;
        }
        else
        {
            push(@lines,$line);
        }
    }
    foreach $line (@lines)
    {
        @raw = split(/\s/,$line);
        push(@shares,$raw[0]);
    }
    foreach $line (@shares)
    {
        `echo ************************************** >> $dir$name-localshares.txt`;
        `echo ************************************** >> $dir$name-localshares.txt`;
        system("net.exe share $line >> $dir$name-localshares.txt");
    }
}

sub registryremove()
{
    my $path = $_[0];
    system("regedit.exe /S $path"."sysinternals-registry-eulas-remove.reg");
}



#Variables
my $cotfdate;#this is the cotf formatted date of yyyy.mm.dd-hhmmGMT
my $cotfname = "";#this is the cotf test name
my $ipaddr = "";#This is the system IP address
my $directory = "c:\\assessment\\";#location where we will store data
my $toolpath = $ARGV[0];#command line parameter point to location of CD with tools on it.
my $logdate = $ARGV[1];#command line parameter that asks for date to collect logs from.
my $os;
my @sysinfo;

#if (!defined $toolpath or !defined $logdate) {die "Missing tool path or date:  collection-script.exe <tool path\> <MM/DD/YYYY>";}
#instead of command line parameters, we'll just ask for the information we need and check it.
system("cls");
$toolpath = &checktoolpath();
$logdate = &checklogdate();

#format the date and time
$cotfdate = datetime();

#What OS are we running on?
($os,@sysinfo) = &whatos($os,\@sysinfo);

#now get the assessment name
($cotfname,$ipaddr) = &assessmentname($cotfname,$ipaddr,$os);
$cotfname = "$cotfdate-$cotfname";

#Now we need to create a collection directory
&makedir($cotfname,$ipaddr,$directory);
$directory = $directory.$cotfname."-".$ipaddr."\\";
$cotfname = $cotfname."-".$ipaddr;

#setup the registry for the sysinternals tools
&registrysetup($toolpath);

#Now lets start the info gathering
#This routine will walk though the commands that the original batch file did.
&collection($directory,$cotfname,$toolpath,$logdate,$os,\@sysinfo);

#remove the registry entries
&registryremove($toolpath);

#now lets move it back to the assessment laptop


print "\n\nCOMPLETE!!";